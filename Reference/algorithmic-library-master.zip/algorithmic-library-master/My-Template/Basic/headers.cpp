#include <bits/stdc++.h>
typedef long long ll;
#define MP make_pair
#define AA first
#define BB second
#define PB push_back
#define SZ size
#define OP begin()
#define ED end()
typedef std::pair<int, int> PII;
/* =========================================================== */
