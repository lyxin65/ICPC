#include<cstdio>
using namespace std;

int main()
{
    int a = 2;
    printf("%p\n", &a);
    return 0;
}
